# Совместная разработка

Порядок: **новая ветка → изменение → тесты → commit → Pull Request → проверка → merge**.

1. Владелец создаёт репозиторий GitHub и добавляет двух участников в Collaborators.
2. Каждый клонирует его отдельно. Один PR — одна понятная задача.
3. Перед новой задачей:

```bash
git switch main
git pull --ff-only
git switch -c feat/short-task-name
```

4. Внесите изменения. Сохраняйте API и статусы из README либо согласуйте миграцию.
5. Запустите `python -m pytest -q` в своём venv; для UI проверьте клавиатуру и телефон.
6. Проверьте `git diff` и `git status`. Добавляйте конкретные файлы, без .env и базы
пользователей. Предоставленный анонимизированный `data/contractors.csv` включён
в проект; новые персональные данные публиковать без разрешения нельзя.

```bash
git add app static tests
git commit -m "feat: краткое описание изменения"
git push -u origin feat/short-task-name
```

7. В GitHub выберите Compare & pull request, base=main. Заполните шаблон, назначьте
другого участника рецензентом. Дождитесь зелёного Tests и замечаний рецензента.
8. После одобрения владелец выполняет merge. Автор этого MVP main не объединяет.
9. Остальные снова обновляют main перед следующей задачей.

При конфликте: `git fetch origin`, `git merge origin/main` в **своей** рабочей ветке,
разберите отмеченные участки, снова тесты, commit и push. Не используйте reset --hard
или force push, если это уничтожает работу товарища. Сначала сохраните изменения
обычным коммитом своей ветки. Распределение файлов: docs/team-plan.md.

## Первое размещение проекта

На момент подготовки не было исходного репозитория и remote. Среда позволила
создать `.git`, но блокировала lock-файлы: начальный коммит и рабочая ветка
не созданы. Все исходники сохранены в рабочей папке. Выполните в своём терминале:

```bash
git status
git config user.name "Ваше имя"
git config user.email "Ваш email GitHub"
git symbolic-ref HEAD refs/heads/main
git commit --allow-empty -m "chore: initialize repository"
git switch -c feat/event-vendors-mvp
git add .gitignore .gitattributes .env.example requirements.txt requirements-dev.txt README.md CONTRIBUTING.md app static tests scripts data/README.md data/contractors.csv data/supplements.json docs .github
git commit -m "feat: event vendor matching MVP"
```

Создайте в GitHub **пустой** репозиторий (без автоматически добавленных README и
лицензии). Подставьте его URL, затем:

```bash
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
git push -u origin feat/event-vendors-mvp
```

В GitHub создайте PR из feat/event-vendors-mvp в main, скопируйте
`docs/pr-description.md`. При установленном и авторизованном GitHub CLI:

```bash
gh pr create --base main --head feat/event-vendors-mvp --title "MVP подбора event-подрядчиков" --body-file docs/pr-description.md
```

Если работаете из ZIP без `.git`, сначала `git init -b main`.
Приведённый блок первого размещения предназначен только для этого нового проекта,
не запускайте его поверх другого существующего репозитория с историей.
