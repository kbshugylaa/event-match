import re

from .ranking import tokens


def explain(profile, request, overlap):
    # Короткая точная цитата о запросе, не оценка качества или пересказ всего профиля.
    sentences = [s.strip(' •—') for s in re.split(r'(?<=[.!?])\s+|\n+|•',profile.description)]
    wishes = tokens(request.wishes)
    candidates = [s for s in sentences if tokens(s)&set(overlap)]
    fragment = max(candidates,key=lambda s:(len(tokens(s)&wishes),len(tokens(s)&set(overlap)),-len(s)),default=None)
    if fragment and len(fragment)>260:
        fragment = fragment[:257].rsplit(' ',1)[0]+'…'
    gap = f'{request.budget_kzt - profile.price_from_kzt:,.2f}'.rstrip('0').rstrip('.').replace(',', ' ')
    first = (f'В описании указано: «{fragment.rstrip(".!?")}».' if fragment else
             f'Профиль поддерживает формат «{request.event_format}» в городе {profile.city}'
             + (f' и язык «{request.language}».' if request.language else '.'))
    return first + f' Разница бюджета со стартовой ценой — {gap} ₸; итоговая стоимость требует уточнения.'
