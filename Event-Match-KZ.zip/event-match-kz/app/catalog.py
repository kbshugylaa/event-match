"""Строгая загрузка исходного каталога. Никаких неявных тестовых данных."""
import ast
import csv
import json
from pathlib import Path

from .models import Profile

LIST_FIELDS = ('categories', 'event_formats', 'languages', 'busy_dates')
BOOL_FIELDS = ('synthetic', 'city_imputed', 'price_imputed')


class CatalogError(ValueError):
    pass


def csv_record(record):
    if None in record or any(value is None for value in record.values()):
        raise ValueError('Число столбцов не совпадает с заголовком')
    for key in LIST_FIELDS:
        raw = record[key].strip()
        if raw.startswith('['):
            try:
                record[key] = json.loads(raw)
            except json.JSONDecodeError:
                record[key] = ast.literal_eval(raw)
        else:
            record[key] = raw.split('|') if raw else []
        if not isinstance(record[key], list):
            raise ValueError(f'{key}: ожидается список')
    for key in BOOL_FIELDS:
        raw = record[key].strip().lower()
        if raw not in ('true', 'false', '1', '0'):
            raise ValueError(f'{key}: ожидается true/false или 1/0')
        record[key] = raw in ('true', '1')
    record['price_from_kzt'] = float(record['price_from_kzt'])
    raw = record['max_hours'].strip()
    record['max_hours'] = None if raw.lower() in ('', 'null', 'none') else float(raw)
    return record


def load_catalog(path: Path) -> list[Profile]:
    if not path.is_file():
        raise CatalogError('Исходный CSV/JSONL не найден. Добавьте каталог и перезапустите сервер.')
    profiles = []
    ids = set()
    try:
        with path.open(encoding='utf-8-sig', newline='') as stream:
            if path.suffix.lower() == '.jsonl':
                records = ((i, json.loads(line)) for i, line in enumerate(stream, 1) if line.strip())
            elif path.suffix.lower() == '.csv':
                sample = stream.read(8192)
                stream.seek(0)
                dialect = csv.Sniffer().sniff(sample, delimiters=',;\t')
                reader = csv.DictReader(stream, dialect=dialect)
                if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
                    raise ValueError('Пустые или повторные заголовки CSV')
                records = ((i, csv_record(row)) for i, row in enumerate(reader, 2))
            else:
                raise ValueError('Поддерживаются только .jsonl и .csv')
            for line, record in records:
                if not isinstance(record, dict):
                    raise ValueError(f'Запись {line}: ожидается JSON-объект')
                # Числовой id допустим, но bool и дробные значения — нет.
                if type(record.get('id')) is int:
                    record['id'] = str(record['id'])
                try:
                    profile = Profile.model_validate(record)
                except ValueError as exc:
                    raise ValueError(f'Запись {line}: {exc}') from exc
                if profile.id in ids:
                    raise ValueError(f'Запись {line}: повторный id {profile.id}')
                ids.add(profile.id)
                profiles.append(profile)
    except (ValueError, TypeError, KeyError, SyntaxError, OSError, csv.Error) as exc:
        raise CatalogError(f'Каталог не прошёл проверку: {exc}') from exc
    if not profiles:
        raise CatalogError('Каталог пуст. Рекомендации недоступны.')
    return profiles


def options(profiles):
    return {
        'cities': sorted({p.city for p in profiles}),
        'categories': sorted({v for p in profiles for v in p.categories}),
        'event_formats': sorted({v for p in profiles for v in p.event_formats}),
        'languages': sorted({v for p in profiles for v in p.languages}),
    }
