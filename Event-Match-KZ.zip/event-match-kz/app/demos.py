"""Поиск подтверждённых примеров исключительно в загруженном каталоге."""
from datetime import timedelta
from itertools import product
import re

from .catalog import options
from .matching import match
from .models import START, END, MatchRequest
from .ranking import tokens


def build_demos(profiles):
    opts = options(profiles)
    found = {}
    def add(key, title, req, note=''):
        result = match(profiles, req)
        found[key] = {'id': key, 'title': title, 'request': req.model_dump(mode='json'),
                      'expected_status': result['status'], 'expected_found': result['found_count'], 'note': note}

    for city, category in product(opts['cities'], opts['categories']):
        pool = [p for p in profiles if p.city == city and category in p.categories]
        if not pool:
            if 'absent' not in found:
                add('absent', 'Категории нет в городе', MatchRequest(city=city, category=category,
                    event_format=opts['event_formats'][0], date=START, budget_kzt=0))
            continue
        budget = max(p.price_from_kzt for p in pool)
        dates = [START + timedelta(days=n) for n in range((END-START).days+1)]
        for fmt in sorted({f for p in pool for f in p.event_formats}):
            baseline = None
            for day in dates:
                req = MatchRequest(city=city, category=category, event_format=fmt, date=day, budget_kzt=budget)
                result = match(profiles, req)
                if not result['found_count'] and 'empty' not in found:
                    add('empty', 'Никто не прошёл условия', req)
                if 0 < result['found_count'] < 3 and len(pool) <= 3 and 'rare' not in found:
                    add('rare', 'Редкая категория', req)
                if result['found_count'] > 3 and day.month < 12 and 'dense' not in found:
                    eligible = [p for p in pool if p.id not in {e['id'] for e in result['excluded']}]
                    # Подтверждаем именно влияние оценки, а не только tie-breaker.
                    for p in eligible:
                        snippets = [s.strip() for s in re.split(r'(?<=[.!?])\s+|\n+|•',p.description) if s.strip()]
                        for snippet in snippets[:4]:
                            wishes = snippet if len(snippet)<=160 else snippet[:157].rsplit(' ',1)[0]+'…'
                            trial = req.model_copy(update={'wishes':wishes})
                            trial_result = match(profiles,trial)
                            ranked_ids = [p['id'] for p in trial_result['recommendations']]
                            if ranked_ids!=sorted(p.id for p in eligible)[:3] and len({c['score'] for c in trial_result['recommendations']})>1:
                                add('dense','Больше трёх • поиск по словам',trial)
                                break
                        if 'dense' in found:
                            break
                eligible_ids = {p.id for p in pool} - {e['id'] for e in result['excluded']}
                if baseline and 'date_a' not in found:
                    before, previous_ids = baseline
                    lost = previous_ids - eligible_ids
                    gained = eligible_ids - previous_ids
                    busy = {e['id'] for e in result['excluded'] if e['reason'] == 'busy'}
                    if lost & busy:
                        names = ', '.join(p.anon_name for p in pool if p.id in lost & busy)
                        note = f'На второй дате из-за занятости исключены: {names}. Сравниваются все подходящие, а не только TOP-3.'
                        add('date_a', 'Календарь • первая дата', before, note)
                        add('date_b', 'Календарь • вторая дата', req, note)
                    elif gained:
                        previous_busy = {e['id'] for e in match(profiles, before)['excluded'] if e['reason'] == 'busy'}
                        if gained & previous_busy:
                            names = ', '.join(p.anon_name for p in pool if p.id in gained & previous_busy)
                            note = f'На второй дате из-за занятости исключены: {names}. Даты показаны в порядке сравнения, не обязательно хронологически.'
                            add('date_a', 'Календарь • первая дата', req, note)
                            add('date_b', 'Календарь • вторая дата', before, note)
                if baseline is None:
                    baseline = req, eligible_ids
            if 'empty' not in found and min(p.price_from_kzt for p in pool) > 0:
                add('empty', 'Никто не прошёл бюджет', MatchRequest(city=city, category=category,
                    event_format=fmt, date=START, budget_kzt=0))
    keys = ('dense', 'rare', 'absent', 'empty', 'date_a', 'date_b')
    return {'scenarios': [found[k] for k in keys if k in found],
            'unavailable': [k for k in keys if k not in found]}
