import hmac
import logging
import os
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .auth import AuthStore, COOKIE, SESSION_SECONDS, LoginInput, RegisterInput
from .catalog import CatalogError, load_catalog, options
from .demos import build_demos
from .explanations import explain
from .matching import REASONS, match, rejection
from .models import START, END, MatchRequest
from .ranking import MODE, relevance
from .supplements import load_supplements

ROOT = Path(__file__).resolve().parent.parent


def create_app(catalog_path=None, db_path=None, supplements_path=None):
    app = FastAPI(title='Event Match KZ', version='0.2.0')
    path = Path(catalog_path or os.environ.get('CATALOG_PATH', ROOT/'data/contractors.csv'))
    auth = AuthStore(db_path or os.environ.get('DATABASE_PATH', ROOT/'var/accounts.sqlite3'))
    app.state.auth = auth
    secure = os.environ.get('COOKIE_SECURE', 'false').lower() == 'true'
    profiles, error, demos = [], None, {'scenarios': [], 'unavailable': []}
    try:
        profiles = load_catalog(path)
        demos = build_demos(profiles)
    except CatalogError as exc:
        logging.warning('%s', exc)
        error = ('Исходный CSV/JSONL отсутствует. Добавьте каталог и перезапустите сервер.'
                 if not path.exists() else 'Каталог не прошёл проверку. Подробности — в журнале сервера.')
    extras, extras_error = {}, None
    try:
        extras = load_supplements(supplements_path or ROOT/'data/supplements.json', profiles, ROOT)
    except (ValueError, OSError) as exc:
        logging.warning('Дополнительные материалы: %s', exc)
        extras_error = 'Дополнительные материалы недоступны: файл не прошёл проверку.'
    opts = options(profiles)

    @app.middleware('http')
    async def security_headers(request, call_next):
        if request.method in {'POST','PUT','PATCH','DELETE'}:
            origin = request.headers.get('origin')
            if request.headers.get('x-app-request') != 'event-match' or (origin and origin != str(request.base_url).rstrip('/')):
                return JSONResponse(status_code=403, content={'detail':{'message':'Запрос отклонён. Обновите страницу и повторите.'}})
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        if not request.url.path.startswith('/static/'):
            response.headers['Cache-Control'] = 'no-store'
        if request.url.path not in {'/docs','/redoc'}:
            response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        return response

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        return JSONResponse(status_code=422, content={'detail': {
            'message':'Проверьте поля формы.',
            'errors':[{'field':'.'.join(str(p) for p in e['loc'][1:]),'message':e['msg']} for e in exc.errors()]}})

    def session(request: Request):
        current = auth.session(request.cookies.get(COOKIE))
        if not current:
            raise HTTPException(401, detail={'message':'Войдите в аккаунт или откройте деморежим.'})
        if request.method != 'GET' and not hmac.compare_digest(request.headers.get('x-csrf-token',''), current['csrf']):
            raise HTTPException(403, detail={'message':'Сессия изменилась. Обновите страницу.'})
        return current

    def public_user(current):
        if not current:
            return {'authenticated':False}
        return {'authenticated':True,'mode':'account' if current['user_id'] else 'demo',
                'name':current['name'] if current['user_id'] else 'Деморежим','csrf':current['csrf']}

    def start_session(request, response, user_id=None):
        auth.revoke(request.cookies.get(COOKIE))
        token = auth.create_session(user_id)
        response.set_cookie(COOKIE,token,max_age=SESSION_SECONDS,httponly=True,
                            secure=secure,samesite='lax',path='/')
        return public_user(auth.session(token))

    @app.get('/api/auth/me')
    def me(request: Request):
        return public_user(auth.session(request.cookies.get(COOKIE)))

    @app.post('/api/auth/register',status_code=201)
    def register(data: RegisterInput, request: Request, response: Response):
        auth.throttle('register:'+request.client.host)
        return start_session(request,response,auth.register(data))

    @app.post('/api/auth/login')
    def login(data: LoginInput, request: Request, response: Response):
        auth.throttle('login-ip:'+request.client.host)
        auth.throttle('login-email:'+data.email)
        return start_session(request,response,auth.login(data))

    @app.post('/api/auth/demo')
    def demo(request: Request, response: Response):
        auth.throttle('demo:'+request.client.host)
        return start_session(request,response)

    @app.post('/api/auth/logout')
    def logout(request: Request, response: Response, current=Depends(session)):
        auth.revoke(request.cookies.get(COOKIE))
        response.delete_cookie(COOKIE,path='/',httponly=True,secure=secure,samesite='lax')
        return {'authenticated':False}

    def data_required():
        if error:
            raise HTTPException(503,detail={'code':'catalog_unavailable','message':error})

    def validate_options(query):
        data_required()
        for field,key in [('city','cities'),('category','categories'),('event_format','event_formats'),('language','languages')]:
            value = getattr(query,field)
            if value is not None and value not in opts[key]:
                raise HTTPException(422,detail={'message':f'Значение поля {field} отсутствует в каталоге.'})

    @app.get('/api/options')
    def get_options(current=Depends(session)):
        return {**opts,'data_ready':error is None,'data_error':error,'catalog_count':len(profiles),'expected_count':66,
                'test_data':'fixtures' in path.parts and 'tests' in path.parts,
                'warnings':[f'Ожидалось 66 профилей, загружено {len(profiles)}.'] if profiles and len(profiles)!=66 else [],
                'calendar':{'start':START.isoformat(),'end':END.isoformat()},'mode':MODE}

    @app.get('/api/demos')
    def get_demos(current=Depends(session)):
        return {**demos,'data_ready':error is None}

    @app.post('/api/match')
    def post_match(query: MatchRequest, current=Depends(session)):
        validate_options(query)
        result = match(profiles,query)
        auth.save_search(current,query.model_dump_json())
        return result

    @app.get('/api/search')
    def saved_search(current=Depends(session)):
        if not current['search_json']:
            return {'request':None,'result':None}
        query = MatchRequest.model_validate_json(current['search_json'])
        validate_options(query)
        return {'request':query.model_dump(mode='json'),'result':match(profiles,query)}

    @app.get('/api/profiles/{profile_id}')
    def get_profile(profile_id: str, current=Depends(session)):
        data_required()
        profile = next((p for p in profiles if p.id == profile_id),None)
        if not profile:
            raise HTTPException(404,detail={'message':'Профиль не найден.'})
        context,explanation,available = None,None,None
        if current['search_json']:
            query = MatchRequest.model_validate_json(current['search_json'])
            context = query.model_dump(mode='json')
            available = query.date not in profile.busy_dates
            if query.city!=profile.city or query.category not in profile.categories:
                explanation = 'Профиль не соответствует городу или категории текущего запроса.'
            else:
                reason = rejection(profile,query)
                explanation = ('Не подходит по текущему запросу: '+REASONS[reason].lower()+'.' if reason else
                               explain(profile,query,relevance(profile,query)[1]))
        return {**profile.model_dump(mode='json'),'supplement':extras.get(profile_id),
                'materials_error':extras_error,'request':context,'explanation':explanation,'available':available}

    @app.get('/')
    @app.get('/login')
    @app.get('/register')
    def public_page():
        return FileResponse(ROOT/'static/index.html')

    @app.get('/services')
    @app.get('/results')
    @app.get('/profile/{profile_id}')
    def private_page(request: Request):
        if not auth.session(request.cookies.get(COOKIE)):
            return RedirectResponse('/login?next='+request.url.path,status_code=303)
        return FileResponse(ROOT/'static/index.html')

    app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
    return app


app = create_app()
