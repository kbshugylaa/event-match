'use strict';
const $ = id => document.getElementById(id);
const defaults = {size:100,theme:'light',palette:'standard',contrast:false,motion:false,links:false,spacing:false};
let settings = {...defaults};
try {
  const stored = JSON.parse(localStorage.getItem('event-match-access') || '{}');
  if (stored && typeof stored === 'object') {
    for (const key of ['contrast','motion','links','spacing']) settings[key] = stored[key] === true;
    settings.theme = stored.theme === 'dark' ? 'dark' : 'light';
    settings.palette = ['red-green','blue-yellow'].includes(stored.palette) ? stored.palette : 'standard';
    settings.size = Number.isFinite(stored.size) ? Math.max(80,Math.min(200,stored.size)) : 100;
  }
} catch { $('storage-note').textContent = 'Хранилище недоступно. Настройки работают до закрытия страницы.'; }
function applySettings(save = true) {
  document.documentElement.style.fontSize = `${settings.size}%`;
  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.dataset.palette = settings.palette;
  $('palette').value = settings.palette;
  for (const [key,cls] of Object.entries({contrast:'contrast',motion:'no-motion',links:'underlined',spacing:'spacious'})) {
    document.documentElement.classList.toggle(cls,settings[key]); $(key).checked = settings[key];
  }
  $('text-size').textContent = `${settings.size}%`; $('theme').value = settings.theme;
  $('text-down').disabled = settings.size <= 80; $('text-up').disabled = settings.size >= 200;
  if (save) try {localStorage.setItem('event-match-access',JSON.stringify(settings));}
  catch {$('storage-note').textContent = 'Не удалось сохранить настройки. Они действуют на этой странице.';}
}
applySettings(false);
$('access-open').onclick = () => $('access-dialog').showModal();
$('access-close').onclick = () => $('access-dialog').close();
$('access-dialog').addEventListener('close',() => $('access-open').focus());
$('text-up').onclick = () => {settings.size = Math.min(200,settings.size+10);applySettings();};
$('text-down').onclick = () => {settings.size = Math.max(80,settings.size-10);applySettings();};
$('text-reset').onclick = () => {settings.size = 100;applySettings();};
$('theme').onchange = e => {settings.theme = e.target.value;applySettings();};
$('palette').onchange = e => {settings.palette = e.target.value;applySettings();};
for (const key of ['contrast','motion','links','spacing']) $(key).onchange = e => {settings[key] = e.target.checked;applySettings();};
$('access-reset').onclick = () => {settings = {...defaults};applySettings();};


