'use strict';
// Общие $ и настройки доступны из accessibility.js. Персональные данные не пишутся в localStorage.
let currentUser={authenticated:false}, currentRequest=null, selectedDemo=null;
const money=value=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(value);
const reasonLabels={busy:'Занятость',format:'Формат мероприятия',budget:'Цена выше бюджета',hours:'Длительность',language:'Язык'};
function el(tag,text,cls){const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;return node;}
function link(text,href,cls){const node=el('a',text,cls);node.href=href;return node;}
function showError(id,error){$(id).textContent=error.message || String(error);$(id).hidden=false;}
async function api(url,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{
    const headers={'Content-Type':'application/json','X-App-Request':'event-match',...options.headers};
    if(currentUser.csrf)headers['X-CSRF-Token']=currentUser.csrf;
    const response=await fetch(url,{...options,headers,signal:controller.signal});
    const body=await response.json();
    if(!response.ok){
      const fieldNames={email:'Email',password:'Пароль',password_confirm:'Подтверждение пароля',name:'Имя'};
      const details=body.detail?.errors?.map(e=>`${fieldNames[e.field]||e.field}: ${e.message}`).join('; ');
      const error=new Error(details||body.detail?.message||'Не удалось выполнить запрос.');error.status=response.status;throw error;
    }
    return body;
  }catch(error){if(error.name==='AbortError')throw new Error('Ответ не получен за 15 секунд. Попробуйте ещё раз.');throw error;}
  finally{clearTimeout(timer);}
}
function post(url,data={}){return api(url,{method:'POST',body:JSON.stringify(data)});}
async function enterDemo(button){button.disabled=true;try{await post('/api/auth/demo');location.assign('/services');}catch(error){showError('global-error',error);button.disabled=false;}}
$('demo-start').onclick=()=>enterDemo($('demo-start'));
$('auth-demo').onclick=()=>enterDemo($('auth-demo'));
$('logout').onclick=async()=>{try{await post('/api/auth/logout');location.replace('/');}catch(error){showError('global-error',error);}};

function authPage(register){
  $('auth-page').hidden=false;
  $('auth-title').textContent=register?'Создать аккаунт':'С возвращением';
  $('auth-subtitle').textContent=register?'Пара минут — и можно выбирать.':'Войдите, чтобы продолжить подбор.';
  $('auth-submit').textContent=register?'Зарегистрироваться':'Войти';
  $('name-field').hidden=!register;$('confirm-field').hidden=!register;
  $('auth-name').required=register;$('auth-confirm').required=register;
  $('auth-password').minLength=register?12:1;
  $('auth-password').autocomplete=register?'new-password':'current-password';
  $('password-hint').hidden=!register;
  $('auth-switch').append(document.createTextNode(register?'Уже есть аккаунт? ':'Ещё нет аккаунта? '),link(register?'Войти':'Зарегистрироваться',register?'/login':'/register'));
  $('show-password').onchange=()=>{for(const id of ['auth-password','auth-confirm'])$(id).type=$('show-password').checked?'text':'password';};
  $('auth-confirm').oninput=()=>$('auth-confirm').setCustomValidity('');
  $('auth-password').oninput=()=>$('auth-confirm').setCustomValidity('');
  $('auth-form').onsubmit=async event=>{
    event.preventDefault();$('auth-error').hidden=true;
    if(register && $('auth-password').value!==$('auth-confirm').value){$('auth-confirm').setCustomValidity('Пароли не совпадают');$('auth-confirm').reportValidity();return;}
    const data={email:$('auth-email').value,password:$('auth-password').value};
    if(register){data.name=$('auth-name').value;data.password_confirm=$('auth-confirm').value;}
    $('auth-submit').disabled=true;$('auth-submit').textContent='Подождите…';
    try{
      await post(register?'/api/auth/register':'/api/auth/login',data);$('auth-form').reset();
      const next=new URLSearchParams(location.search).get('next');
      location.assign(!register && /^\/(services|results|profile\/[A-Za-z0-9_-]+)$/.test(next||'')?next:'/services');
    }catch(error){showError('auth-error',error);$('auth-submit').disabled=false;$('auth-submit').textContent=register?'Зарегистрироваться':'Войти';}
  };
}

function fillRequest(request){if(!request)return;for(const [key,value]of Object.entries(request))if($(key))$(key).value=value??'';if(request.hours||request.language||request.wishes)$('optional-fields').open=true;highlightCategory();}
function highlightCategory(){for(const button of $('category-picker').querySelectorAll('button')){const selected=button.dataset.category===$('category').value;button.setAttribute('aria-pressed',String(selected));}}
async function setupSearch(){
  const opts=await api('/api/options');
  if(!opts.data_ready){$('data-notice').textContent=opts.data_error;showError('global-error',new Error(opts.data_error));return false;}
  for(const [id,key]of [['city','cities'],['category','categories'],['event_format','event_formats'],['language','languages']])for(const value of opts[key])$(id).add(new Option(value,value));
  $('request-fields').disabled=false;
  $('data-notice').textContent=`${opts.test_data?'ТЕСТОВЫЕ ФИКСТУРЫ. ':''}${opts.catalog_count} профилей · ${opts.categories.length} категорий. ${opts.warnings.join(' ')}`;
  for(const [index,category]of opts.categories.entries()){
    const button=el('button',null,'category-tile');button.type='button';button.dataset.category=category;button.setAttribute('aria-pressed','false');
    button.append(el('span',String(index+1).padStart(2,'0'),'category-number'),el('span',category));
    button.onclick=()=>{$('category').value=category;highlightCategory();$('category').focus();};$('category-picker').append(button);
  }
  $('category').onchange=highlightCategory;
  const saved=await api('/api/search');currentRequest=saved.request;fillRequest(currentRequest);
  $('request').onsubmit=async event=>{
    event.preventDefault();if(!$('request').reportValidity())return;
    const values=Object.fromEntries(new FormData($('request')));
    const query={...values,budget_kzt:Number(values.budget_kzt),hours:values.hours?Number(values.hours):null,language:values.language||null};
    $('submit').disabled=true;$('submit').textContent='Ищем подходящих…';$('form-error').hidden=true;
    try{await post('/api/match',query);location.assign('/results'+(selectedDemo?'?demo='+encodeURIComponent(selectedDemo):''));}
    catch(error){showError('form-error',error);$('form-error').focus();$('submit').disabled=false;$('submit').textContent='Найти подрядчиков →';}
  };
  $('request').addEventListener('input',()=>{selectedDemo=null;$('demo-note').textContent='';if(location.pathname==='/results'){$('scenario-note').hidden=true;$('result-status').textContent='Условия изменены. Повторите поиск.';}});
  if(location.pathname==='/services'){
    const demos=await api('/api/demos');
    for(const scenario of demos.scenarios){const button=el('button',scenario.title);button.type='button';button.onclick=()=>{fillRequest(scenario.request);selectedDemo=scenario.id;$('demo-note').textContent=scenario.note||'Сценарий проверен по каталогу. Параметры можно изменить.';$('request').requestSubmit();};$('demos').append(button);}
    if(currentUser.mode==='demo')$('demos-details').open=true;
  } else if(new URLSearchParams(location.search).has('demo')) {
    const id=new URLSearchParams(location.search).get('demo'),demos=await api('/api/demos');
    const scenario=demos.scenarios.find(s=>s.id===id&&Object.entries(s.request).every(([key,value])=>value===currentRequest?.[key]));
    if(scenario?.note){$('scenario-note').hidden=false;$('scenario-note').textContent=scenario.note;}
  }
  return saved;
}
function badges(profile){const group=el('div',null,'badges');for(const [key,label]of [['synthetic','Синтетический профиль'],['city_imputed','Город восстановлен'],['price_imputed','Цена восстановлена']])if(profile[key])group.append(el('span',label,'badge'));return group;}
function facts(profile){const group=el('dl',null,'profile-facts');for(const [name,value]of [['Город',profile.city],['Форматы',profile.event_formats.join(', ')],['Языки',profile.languages.join(', ')],['Длительность',profile.max_hours===null?'Не привязана к часам присутствия':`До ${profile.max_hours} ч`]]){const row=el('div');row.append(el('dt',name),el('dd',value));group.append(row);}return group;}
function renderResults(result){
  if(!result){$('result-status').textContent='Сначала укажите параметры события';return;}
  $('query-summary').textContent=`${currentRequest.category} · ${currentRequest.city} · ${currentRequest.date.split('-').reverse().join('.')} · до ${money(currentRequest.budget_kzt)} ₸`;
  const titles={matched:`Найдено ${result.found_count} · Показано ${result.shown_count}`,no_category_in_city:'В этом городе нет выбранной услуги',no_eligible_candidates:'По этим условиям никого не нашлось'};
  $('result-status').textContent=titles[result.status];
  $('shortfall').hidden=!result.shortfall;$('shortfall').textContent=result.shortfall||'';
  for(const p of result.recommendations){
    const card=el('article',null,'card'),head=el('div',null,'card-head'),identity=el('div',null,'identity');
    identity.append(el('div',p.anon_name.split(' ').map(s=>s[0]).slice(0,2).join(''),'avatar'));
    const names=el('div');names.append(el('h3',p.anon_name),el('p',`${p.categories.join(' · ')} / ${p.city}`,'subline'));identity.append(names);head.append(identity,el('div',`от ${money(p.price_from_kzt)} ₸`,'price'));card.append(head);
    card.append(el('p',`${p.event_formats.join(', ')} · ${p.languages.join(', ')}${p.max_hours===null?'':` · до ${p.max_hours} ч`}`,'card-meta'),el('p',`✓ Свободен по календарю на ${currentRequest.date.split('-').reverse().join('.')}`,'available'));
    const why=el('div',null,'explanation');why.append(el('strong','Почему подходит'),el('p',p.explanation));card.append(why,badges(p));
    card.append(link('Посмотреть профиль →',`/profile/${encodeURIComponent(p.id)}`,'profile-link'));$('results').append(card);
  }
  if(result.pool_count){$('funnel').hidden=false;$('funnel-content').append(el('p',`В городе и категории: ${result.pool_count}. Подошло: ${result.found_count}. Каждый отказ учтён один раз.`));const list=el('ol');for(const [key,count]of Object.entries(result.funnel))list.append(el('li',`${reasonLabels[key]}: ${count}`));$('funnel-content').append(list);const busy=result.excluded.filter(p=>p.reason==='busy');if(busy.length)$('funnel-content').append(el('p',`Заняты на дату: ${busy.map(p=>`${p.name} (${p.id})`).join(', ')}.`));}
}
function profileSection(title){const section=el('section',null,'profile-section');section.append(el('h2',title));return section;}
async function renderProfile(id){
  const p=await api('/api/profiles/'+encodeURIComponent(id));
  const main=$('profile-content'),hero=el('div',null,'profile-hero'),avatar=el('div',p.anon_name.split(' ').map(s=>s[0]).slice(0,2).join(''),'avatar avatar-large');avatar.setAttribute('aria-label','Фотография не предоставлена');
  const title=el('div');title.append(el('p',p.categories.join(' · '),'eyebrow'),el('h1',p.anon_name),el('p',p.city,'lead'),badges(p));hero.append(avatar,title);main.append(hero);
  const columns=el('div',null,'profile-columns'),details=el('div'),aside=el('aside',null,'contact-card');
  const about=profileSection('О подрядчике');about.append(el('p',p.description||'Описание не предоставлено.','description'),el('p','Описание из анонимизированного датасета. Заявления автора не проверялись сервисом.','quiet'));details.append(about);
  if(p.explanation){const why=profileSection('Соответствие вашему запросу');why.append(el('p',p.explanation));details.append(why);}
  const properties=profileSection('Условия работы');properties.append(facts(p));details.append(properties);
  const portfolio=profileSection('Примеры работ'),items=p.supplement?.portfolio||[];
  if(!items.length)portfolio.append(el('div','Примеры работ пока не добавлены','material-empty'));
  else{const gallery=el('div',null,'gallery');for(const item of items){const button=el('button',null,'gallery-item'),image=el('img');image.src=item.src;image.alt=item.alt;image.loading='lazy';button.append(image,el('span',item.caption));if(item.demonstration)button.append(el('span','Демонстрационный материал','badge'));button.onclick=()=>{$('photo-large').src=item.src;$('photo-large').alt=item.alt;$('photo-caption').textContent=`${item.demonstration?'Демонстрационный материал. ':''}${item.caption} Источник: ${item.source}`;$('photo-dialog').showModal();};gallery.append(button);}portfolio.append(gallery);}
  details.append(portfolio);
  aside.append(el('p','Стоимость от','quiet'),el('p',`${money(p.price_from_kzt)} ₸`,'profile-price'),el('p','Итоговая цена согласуется с подрядчиком.','quiet'));
  if(p.request)aside.append(el('p',`${p.available?'✓ Свободен':'× Занят'} по календарю на ${p.request.date.split('-').reverse().join('.')}`,'availability-block'));
  else aside.append(el('p','Выберите дату для проверки доступности.','availability-block'),link('Указать параметры','/services'));
  aside.append(el('h2','Связаться'));
  const extra=p.supplement;
  if(extra?.phone)aside.append(link('Позвонить','tel:'+extra.phone.replace(/[ ()-]/g,''),'contact-link'));
  if(extra?.messenger){const a=link('Написать в мессенджере',extra.messenger,'contact-link');a.target='_blank';a.rel='noopener noreferrer';aside.append(a);}
  if(extra?.email){const q=p.request;const body=`Здравствуйте! Интересуют ваши услуги.${q?`\nДата: ${q.date}\nГород: ${q.city}\nФормат: ${q.event_format}\nБюджет: ${money(q.budget_kzt)} ₸${q.hours?`\nДлительность: ${q.hours} ч`:''}`:''}\nПодскажите, пожалуйста, условия и итоговую стоимость.`;aside.append(link('Написать письмо',`mailto:${extra.email}?subject=${encodeURIComponent('Запрос на проведение мероприятия')}&body=${encodeURIComponent(body)}`,'contact-link'));}
  if(!extra?.phone&&!extra?.email&&!extra?.messenger)aside.append(el('p','Контакты не предоставлены в демонстрационном датасете.','material-empty'));
  if(extra)aside.append(el('p',`Источник дополнительных материалов: ${extra.source}`,'quiet'));
  if(p.materials_error)aside.append(el('p',p.materials_error,'error'));
  aside.append(el('p','Обращение не является бронированием.','quiet'));columns.append(details,aside);main.append(columns);
}
$('photo-close').onclick=()=>$('photo-dialog').close();
async function init(){
  try{
    currentUser=await api('/api/auth/me');
    $('logout').hidden=!currentUser.authenticated;$('nav-services').hidden=!currentUser.authenticated;
    $('account-label').textContent=currentUser.authenticated?(currentUser.mode==='demo'?'Деморежим':currentUser.name):'';
    const route=location.pathname;
    if(route==='/')$('welcome-page').hidden=false;
    else if(route==='/login'||route==='/register')authPage(route==='/register');
    else if(!currentUser.authenticated)location.replace('/login?next='+encodeURIComponent(route));
    else if(route==='/services'||route==='/results'){
      $(route==='/services'?'services-page':'results-page').hidden=false;
      if(route==='/results')$('results-form-target').append($('search-panel'));
      const saved=await setupSearch();if(route==='/results')renderResults(saved?.result);
    }else if(route.startsWith('/profile/')){$('profile-page').hidden=false;await renderProfile(decodeURIComponent(route.slice('/profile/'.length)));}
  }catch(error){showError('global-error',error);}
  finally{$('loading').hidden=true;}
}
init();
