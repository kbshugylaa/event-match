"""python -m scripts.verify_catalog data/contractors.jsonl"""
import argparse
import json
from pathlib import Path
from statistics import median
from time import perf_counter
from tempfile import TemporaryDirectory

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.demos import build_demos
from app.main import create_app


def main():
    parser = argparse.ArgumentParser(description='Проверка каталога, сценариев и времени ответа API')
    parser.add_argument('catalog', type=Path)
    parser.add_argument('--output', type=Path, help='JSON-отчёт с точными демо-запросами')
    args = parser.parse_args()
    start = perf_counter()
    profiles = load_catalog(args.catalog)
    demos = build_demos(profiles)
    startup_ms = (perf_counter()-start)*1000
    temporary = TemporaryDirectory()
    client = TestClient(create_app(args.catalog,Path(temporary.name)/'benchmark.sqlite3'))
    client.headers['X-App-Request']='event-match'
    session = client.post('/api/auth/demo').json()
    client.headers['X-CSRF-Token']=session['csrf']
    timings = []
    for scenario in demos['scenarios']:
        for _ in range(20):
            start = perf_counter()
            response = client.post('/api/match',json=scenario['request'])
            timings.append((perf_counter()-start)*1000)
            response.raise_for_status()
            result = response.json()
            assert result['status'] == scenario['expected_status']
            assert result['found_count'] == scenario['expected_found']
            assert result['shown_count'] <= 3
            assert result['pool_count'] == result['found_count'] + sum(result['funnel'].values())
    report = {'catalog':str(args.catalog),'count':len(profiles),
              'fixture_only':'fixtures' in args.catalog.parts and 'tests' in args.catalog.parts,
              'mode':'words-v1','catalog_and_demos_ms':round(startup_ms,2),
              'benchmark':{'transport':'FastAPI TestClient, без сети и отрисовки браузера',
                           'requests':len(timings),'median_ms':round(median(timings),2) if timings else None,
                           'max_ms':round(max(timings),2) if timings else None},**demos}
    text = json.dumps(report,ensure_ascii=False,indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text,encoding='utf-8')
    print(text)
    client.close()
    temporary.cleanup()


if __name__ == '__main__':
    main()
