// Проверка отказа localStorage без настоящего браузера. Полная UI-проверка — вручную.
const {test} = require('node:test');
const assert = require('node:assert/strict');
const {readFileSync} = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = readFileSync(path.join(__dirname,'../static/accessibility.js'),'utf8');

function boot(storage) {
  const nodes = new Map();
  const getElementById = id => {
    if(!nodes.has(id)) nodes.set(id,{value:'',textContent:'',checked:false,disabled:false,addEventListener(){}});
    return nodes.get(id);
  };
  const classes = new Set();
  const root = {style:{},dataset:{},classList:{toggle(name,on){on?classes.add(name):classes.delete(name);}}};
  vm.runInNewContext(source,{
    document:{getElementById,documentElement:root},localStorage:storage,
    AbortController, setTimeout:()=>0, clearTimeout(){}, fetch:()=>new Promise(()=>{}),
  });
  return {root,nodes,classes};
}

test('запрет localStorage не мешает запуску и изменению размера',()=>{
  const app=boot({getItem(){throw Error('blocked');},setItem(){throw Error('blocked');}});
  assert.equal(app.root.style.fontSize,'100%');
  app.nodes.get('text-up').onclick();
  assert.equal(app.root.style.fontSize,'110%');
  assert.match(app.nodes.get('storage-note').textContent,/Не удалось сохранить/);
  app.nodes.get('access-reset').onclick();
  assert.equal(app.root.style.fontSize,'100%');
});

test('восстановление настроек и общий сброс',()=>{
  let saved=JSON.stringify({size:150,theme:'dark',palette:'red-green',contrast:true,motion:true,links:true,spacing:true});
  const storage={getItem:()=>saved,setItem:(key,value)=>{saved=value;}};
  const app=boot(storage);
  assert.equal(app.root.style.fontSize,'150%');
  assert.equal(app.root.dataset.theme,'dark');
  assert.equal(app.root.dataset.palette,'red-green');
  assert.deepEqual([...app.classes],['contrast','no-motion','underlined','spacious']);
  app.nodes.get('access-reset').onclick();
  const reloaded=boot(storage);
  assert.equal(reloaded.root.style.fontSize,'100%');
  assert.equal(reloaded.root.dataset.theme,'light');
  assert.equal(reloaded.root.dataset.palette,'standard');
  assert.equal(reloaded.classes.size,0);
});

test('повреждённые настройки и пределы размера безопасны',()=>{
  const corrupt=boot({getItem:()=>'{broken',setItem(){}});
  assert.equal(corrupt.root.style.fontSize,'100%');
  const extreme=boot({getItem:()=>JSON.stringify({size:10000,theme:'unknown',contrast:'false'}),setItem(){}});
  assert.equal(extreme.root.style.fontSize,'200%');
  assert.equal(extreme.nodes.get('text-up').disabled,true);
  assert.equal(extreme.root.dataset.theme,'light');
  assert.equal(extreme.classes.size,0);
});

