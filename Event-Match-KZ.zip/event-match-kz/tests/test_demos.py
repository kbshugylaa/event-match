from datetime import date

from app.demos import build_demos


def test_date_demo_when_initial_day_is_busy(profiles):
    p = profiles[0].model_copy(update={'busy_dates':[date(2026,9,23)]})
    scenarios = {s['id']:s for s in build_demos([p])['scenarios']}
    assert scenarios['date_a']['expected_found'] == 1
    assert scenarios['date_b']['expected_found'] == 0
    assert scenarios['date_b']['request']['date'] == '2026-09-23'
