import hashlib
from pathlib import Path

from app.catalog import load_catalog,options
from app.demos import build_demos
from app.matching import match
from app.models import MatchRequest

SOURCE=Path(__file__).resolve().parents[1]/'data/contractors.csv'


def test_source_integrity_and_real_values():
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='6a724b6b7dfb5973343e68ba18dadb60fc807d87e3d78f03ee86fb26cb089f7d'
    profiles=load_catalog(SOURCE)
    assert len(profiles)==len({p.id for p in profiles})==66
    assert len(options(profiles)['categories'])==17
    assert sum(p.synthetic for p in profiles)==13
    assert sum(len(p.busy_dates) for p in profiles)==3337


def test_all_real_demos_are_valid():
    profiles=load_catalog(SOURCE)
    demos=build_demos(profiles)
    assert not demos['unavailable']
    for scenario in demos['scenarios']:
        result=match(profiles,MatchRequest(**scenario['request']))
        assert result['status']==scenario['expected_status']
        assert result['found_count']==scenario['expected_found']
        assert result['pool_count']==result['found_count']+sum(result['funnel'].values())
        assert result['shown_count']<=3
