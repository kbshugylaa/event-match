import time

import pytest
from fastapi.testclient import TestClient

from app.auth import COOKIE, hash_password, verify_password
from app.main import create_app
from tests.conftest import FIXTURE

REGISTRATION={'name':'Тестовый пользователь','email':'user@example.test','password':'a secure passphrase 2026','password_confirm':'a secure passphrase 2026'}


@pytest.fixture
def client(tmp_path):
    return TestClient(create_app(FIXTURE,tmp_path/'accounts.sqlite3'),headers={'X-App-Request':'event-match'})


def register(client):
    response=client.post('/api/auth/register',json=REGISTRATION)
    assert response.status_code==201,response.text
    client.headers['X-CSRF-Token']=response.json()['csrf']
    return response


def test_hashes_are_salted_and_verifiable():
    one=hash_password('long password here')
    two=hash_password('long password here')
    assert one!=two and 'long password here' not in one
    assert verify_password('long password here',one)
    assert not verify_password('wrong',one)


@pytest.mark.parametrize('url',['/api/options','/api/demos','/api/search','/api/profiles/test-01'])
def test_private_api_requires_session(client,url):
    assert client.get(url).status_code==401


@pytest.mark.parametrize('url',['/services','/results','/profile/test-01'])
def test_direct_pages_require_session(client,url):
    response=client.get(url,follow_redirects=False)
    assert response.status_code==303 and response.headers['location'].startswith('/login?next=')


def test_registration_login_logout_and_persistent_store(client,request_data):
    response=register(client)
    cookie=response.headers['set-cookie'].lower()
    assert 'httponly' in cookie and 'samesite=lax' in cookie
    token=client.cookies.get(COOKIE)
    assert client.post('/api/match',json=request_data).status_code==200
    assert client.get('/api/search').json()['request']['city']==request_data['city']
    # Перезапуск приложения с той же SQLite сохраняет аккаунт, сессию и запрос.
    restarted=TestClient(create_app(FIXTURE,client.app.state.auth.path),headers={'X-App-Request':'event-match'})
    restarted.cookies.set(COOKIE,token)
    assert restarted.get('/api/auth/me').json()['name']==REGISTRATION['name']
    assert restarted.get('/api/search').json()['request']['city']==request_data['city']
    with client.app.state.auth.connect() as db:
        user=db.execute('SELECT * FROM users').fetchone()
        stored=db.execute('SELECT * FROM sessions').fetchone()
        assert user['password_hash'].startswith('scrypt$') and REGISTRATION['password'] not in user['password_hash']
        assert stored['token_hash']!=token
    assert client.post('/api/auth/logout').status_code==200
    assert restarted.get('/api/options').status_code==401
    assert client.post('/api/auth/login',json={'email':'USER@example.test','password':REGISTRATION['password']}).status_code==200


def test_duplicate_and_wrong_password(client):
    register(client)
    assert client.post('/api/auth/register',json=REGISTRATION).status_code==409
    bad=client.post('/api/auth/login',json={'email':REGISTRATION['email'],'password':'wrong'})
    assert bad.status_code==401


@pytest.mark.parametrize('update',[{'password':'short','password_confirm':'short'},{'password_confirm':'does not match 123'},
                                  {'name':'   '},{'email':'not-email'},{'email':'user@example.test\r\nAttack: yes'}])
def test_registration_validation(client,update):
    assert client.post('/api/auth/register',json={**REGISTRATION,**update}).status_code==422


def test_csrf_and_origin_rejected(client,request_data):
    register(client)
    assert client.post('/api/match',json=request_data,headers={'X-CSRF-Token':'wrong'}).status_code==403
    assert client.post('/api/auth/logout',headers={'Origin':'https://evil.example'}).status_code==403
    client.headers.pop('X-App-Request')
    assert client.post('/api/auth/demo').status_code==403


def test_demo_cannot_read_account_search(client,request_data):
    register(client)
    client.post('/api/match',json=request_data)
    old_token=client.cookies.get(COOKIE)
    demo=client.post('/api/auth/demo').json()
    assert demo['mode']=='demo' and demo['name']=='Деморежим'
    assert client.get('/api/search').json()['request'] is None
    assert client.app.state.auth.session(old_token) is None
    assert 'email' not in client.get('/api/auth/me').json()


def test_expired_session(client):
    register(client)
    with client.app.state.auth.connect() as db:
        db.execute('UPDATE sessions SET expires_at=?',(int(time.time())-1,))
    assert client.get('/api/search').status_code==401


def test_profile_context_and_missing_materials(client,request_data):
    user=client.post('/api/auth/demo').json();client.headers['X-CSRF-Token']=user['csrf']
    first=client.get('/api/profiles/test-01').json()
    assert first['supplement'] is None and first['available'] is None
    client.post('/api/match',json=request_data)
    p=client.get('/api/profiles/test-01').json()
    assert p['available'] is True and p['explanation'] and p['request']['date']=='2026-10-01'
    client.post('/api/match',json={**request_data,'date':'2026-10-02'})
    p=client.get('/api/profiles/test-01').json()
    assert p['available'] is False and 'заняты' in p['explanation']
    assert client.get('/api/profiles/missing').status_code==404


def test_rate_limit(client):
    for _ in range(20): client.app.state.auth.throttle('test-limit')
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as exc: client.app.state.auth.throttle('test-limit')
    assert exc.value.status_code==429
