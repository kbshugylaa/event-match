import csv
import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.catalog import CatalogError, load_catalog
from app.demos import build_demos
from app.main import create_app
from app.matching import match
from app.models import MatchRequest
from tests.conftest import FIXTURE


def test_missing_catalog_is_not_empty_results(tmp_path, request_data):
    client = TestClient(create_app(tmp_path/'missing.jsonl',tmp_path/'users.sqlite3'))
    client.headers['X-App-Request']='event-match'
    login=client.post('/api/auth/demo').json()
    client.headers['X-CSRF-Token']=login['csrf']
    assert client.get('/').status_code == 200
    assert client.get('/api/options').json()['data_ready'] is False
    response = client.post('/api/match',json=request_data)
    assert response.status_code == 503
    assert response.json()['detail']['code'] == 'catalog_unavailable'
    assert client.get('/api/demos').json()['scenarios'] == []


@pytest.fixture(scope='module')
def client(tmp_path_factory):
    client=TestClient(create_app(FIXTURE,tmp_path_factory.mktemp('db')/'users.sqlite3'))
    client.headers['X-App-Request']='event-match'
    login=client.post('/api/auth/demo').json()
    client.headers['X-CSRF-Token']=login['csrf']
    return client


def test_api_options_and_contract(client, request_data):
    opts = client.get('/api/options').json()
    assert opts['data_ready'] and opts['catalog_count'] == 6 and opts['warnings']
    assert 'Площадка' in opts['categories']
    data = client.post('/api/match',json=request_data).json()
    assert data['status'] == 'matched' and data['shown_count'] == 3 and data['found_count'] == 4
    absent = client.post('/api/match',json={**request_data,'category':'Площадка'})
    assert absent.status_code == 200 and absent.json()['status'] == 'no_category_in_city'


@pytest.mark.parametrize('update',[
    {'date':'2026-09-22'},{'date':'2027-01-01'},{'date':'bad'},{'date':1790000000},
    {'budget_kzt':-1},{'budget_kzt':True},{'budget_kzt':'1000'},
    {'hours':0},{'hours':-1},{'city':''},{'city':'Неизвестный город'},
    {'language':'Неизвестный язык'},{'extra':'field'}, {'wishes':'a'*1001}])
def test_invalid_input(client, request_data, update):
    assert client.post('/api/match',json={**request_data,**update}).status_code == 422


@pytest.mark.parametrize('day',['2026-09-23','2026-12-31'])
def test_calendar_endpoints(client, request_data, day):
    assert client.post('/api/match',json={**request_data,'date':day}).status_code == 200


def test_missing_required(client, request_data):
    del request_data['category']
    assert client.post('/api/match',json=request_data).status_code == 422


@pytest.mark.parametrize('update',[
    {'categories':'Ведущий'}, {'categories':['']}, {'languages':[]},
    {'price_from_kzt':-1},{'price_from_kzt':float('nan')},{'price_from_kzt':True},
    {'busy_dates':['2026-10-02','2026-10-02']},{'busy_dates':['2027-01-01']},
    {'busy_dates':None},{'busy_dates':[1790000000]},{'synthetic':'false'}, {'city':''}, {'max_hours':0}])
def test_bad_profile_is_rejected(tmp_path, profiles, update):
    record = {**profiles[0].model_dump(mode='json'),**update}
    path = tmp_path/'invalid.jsonl'; path.write_text(json.dumps(record),encoding='utf-8')
    with pytest.raises(CatalogError): load_catalog(path)


def test_duplicate_id(tmp_path):
    path = tmp_path/'duplicate.jsonl'
    first = FIXTURE.read_text(encoding='utf-8').splitlines()[0]
    path.write_text(first+'\n'+first,encoding='utf-8')
    with pytest.raises(CatalogError,match='повторный id'): load_catalog(path)


@pytest.mark.parametrize('text',['[]','null','12','"string"','{bad json',''])
def test_invalid_document_shape(tmp_path, text):
    path = tmp_path/'bad.jsonl'
    path.write_text(text, encoding='utf-8')
    with pytest.raises(CatalogError): load_catalog(path)


@pytest.mark.parametrize('delimiter',[',',';','\t'])
@pytest.mark.parametrize('list_encoding',['json','python'])
def test_csv_safe_lists(tmp_path, profiles, delimiter, list_encoding):
    record = profiles[0].model_dump(mode='json')
    for key in ['categories','event_formats','languages','busy_dates']:
        record[key] = json.dumps(record[key],ensure_ascii=False) if list_encoding == 'json' else repr(record[key])
    path=tmp_path/'valid.csv'
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=record.keys(),delimiter=delimiter); writer.writeheader(); writer.writerow(record)
    assert load_catalog(path) == [profiles[0]]


def test_csv_does_not_execute_code(tmp_path, profiles):
    record = profiles[0].model_dump(mode='json')
    for key in ['categories','event_formats','languages','busy_dates']: record[key]=json.dumps(record[key])
    record['categories']="[__import__('os').system('echo UNSAFE')]"
    path=tmp_path/'malicious.csv'
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=record.keys()); writer.writeheader(); writer.writerow(record)
    with pytest.raises(CatalogError): load_catalog(path)


def test_fixture_demos_are_verified(profiles):
    demos = build_demos(profiles)
    assert not demos['unavailable']
    for scenario in demos['scenarios']:
        result = match(profiles,MatchRequest(**scenario['request']))
        assert result['status'] == scenario['expected_status']
        assert result['found_count'] == scenario['expected_found']
    dates={s['id']:s for s in demos['scenarios'] if s['id'].startswith('date_')}
    assert {k:v for k,v in dates['date_a']['request'].items() if k!='date'} == {k:v for k,v in dates['date_b']['request'].items() if k!='date'}
    second = match(profiles, MatchRequest(**dates['date_b']['request']))
    busy_names = [e['name'] for e in second['excluded'] if e['reason'] == 'busy']
    assert busy_names and any(name in dates['date_b']['note'] for name in busy_names)
