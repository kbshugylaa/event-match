import json

import pytest
from pydantic import ValidationError

from app.supplements import Supplement,load_supplements


@pytest.mark.parametrize('changes',[{'phone':'<script>'},{'email':'a@example.com?bcc=other@example.com'},
    {'messenger':'javascript:alert(1)'},{'messenger':'https://evil.example/a'},
    {'portfolio':[{'src':'/static/portfolio/../secret.png','alt':'a','caption':'b','source':'c'}]}])
def test_unsafe_materials_rejected(changes):
    with pytest.raises(ValidationError): Supplement.model_validate({'source':'test',**changes})


def test_provided_contacts_and_gallery(profiles,tmp_path):
    folder=tmp_path/'static/portfolio';folder.mkdir(parents=True)
    (folder/'test.png').write_bytes(b'test-only-placeholder')
    data={'test-01':{'source':'Только тестовая фикстура','phone':'+7 (700) 000-00-00',
        'email':'fixture@example.test','messenger':'https://t.me/example',
        'portfolio':[{'src':'/static/portfolio/test.png','alt':'Тестовый материал','caption':'Тест',
                      'source':'Фикстура','demonstration':True}]}}
    file=tmp_path/'extras.json';file.write_text(json.dumps(data),encoding='utf-8')
    loaded=load_supplements(file,profiles,tmp_path)
    assert loaded['test-01']['email']=='fixture@example.test'
    assert loaded['test-01']['portfolio'][0]['demonstration'] is True


def test_unknown_profile_rejected(profiles,tmp_path):
    file=tmp_path/'extras.json';file.write_text('{"unknown":{"source":"test"}}',encoding='utf-8')
    with pytest.raises(ValueError): load_supplements(file,profiles,tmp_path)
