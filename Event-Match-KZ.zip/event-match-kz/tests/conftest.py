from pathlib import Path

import pytest

from app.catalog import load_catalog
from app.models import MatchRequest

FIXTURE = Path(__file__).parent / 'fixtures/catalog.jsonl'


@pytest.fixture
def profiles():
    return load_catalog(FIXTURE)


@pytest.fixture
def request_data():
    return dict(city='Тестоград', date='2026-10-01', event_format='Свадьба', category='Ведущий', budget_kzt=150000)


@pytest.fixture
def query(request_data):
    return MatchRequest(**request_data)
