from datetime import date

from app.matching import match


def ids(result):
    return [p['id'] for p in result['recommendations']]


def test_busy_and_changed_date(profiles, query):
    first = match(profiles, query)
    second = match(profiles, query.model_copy(update={'date': date(2026, 10, 2)}))
    assert 'test-01' in ids(first) and 'test-01' not in ids(second)
    assert second['found_count'] == first['found_count'] - 1
    assert second['excluded'] == [{'id': 'test-01', 'name': 'Тестовый профиль 01', 'reason': 'busy'}]


def test_budget_boundary(profiles, query):
    assert match([profiles[0]], query.model_copy(update={'budget_kzt':100000}))['found_count'] == 1
    assert match([profiles[0]], query.model_copy(update={'budget_kzt':99999.99}))['funnel']['budget'] == 1


def test_format_and_language(profiles, query):
    result = match(profiles, query.model_copy(update={'event_format':'Корпоратив', 'language':'Қазақша'}))
    assert ids(result) == ['test-01']
    assert result['funnel']['format'] == 2
    assert result['funnel']['language'] == 1


def test_hours_and_null(profiles, query):
    result = match(profiles, query.model_copy(update={'hours':6}))
    assert set(ids(result)) == {'test-01','test-03'}
    result = match(profiles, query.model_copy(update={'category':'Декоратор','hours':100}))
    assert ids(result) == ['test-05']
    assert result['recommendations'][0]['max_hours'] is None
    assert 'неогранич' not in result['recommendations'][0]['explanation']


def test_three_statuses_and_shortfall(profiles, query):
    assert match(profiles, query)['status'] == 'matched'
    assert match(profiles, query.model_copy(update={'category':'Площадка'}))['status'] == 'no_category_in_city'
    empty = match(profiles, query.model_copy(update={'budget_kzt':0}))
    assert empty['status'] == 'no_eligible_candidates' and empty['shortfall']
    rare = match(profiles, query.model_copy(update={'category':'Декоратор'}))
    assert rare['found_count'] == rare['shown_count'] == 1 and rare['shortfall']


def test_limit_determinism_and_relevance(profiles, query):
    query = query.model_copy(update={'wishes':'Импровизация юмор музыка камерная атмосфера'})
    result = match(profiles, query)
    assert result['found_count'] == 4 and result['shown_count'] == 3
    assert ids(result)[0] == 'test-04'  # Самый дорогой: цена не заменяет релевантность.
    assert match(list(reversed(profiles)), query) == result
    assert match(profiles, query) == result


def test_tie_breaker_is_id(profiles, query):
    profiles = [p.model_copy(update={'description':''}) for p in profiles]
    assert ids(match(list(reversed(profiles)), query)) == ['test-01','test-02','test-03']


def test_funnel_disjoint(profiles, query):
    # Один профиль одновременно нарушает пять условий, засчитывается лишь busy.
    p = profiles[0].model_copy(update={'busy_dates':[query.date],'event_formats':['Другое'],
                                     'price_from_kzt':999999,'max_hours':1,'languages':['English']})
    result = match([p,*profiles[1:]], query.model_copy(update={'hours':6,'language':'Қазақша'}))
    assert result['funnel'] == {'busy':1,'format':0,'budget':0,'hours':2,'language':1}
    assert result['pool_count'] == result['found_count'] + sum(result['funnel'].values())
    assert len({p['id'] for p in result['excluded']}) == sum(result['funnel'].values())


def test_venue_calendar(profiles, query):
    result = match(profiles, query.model_copy(update={'category':'Площадка','city':'Другой тестовый город',
                   'date':date(2026,10,2),'budget_kzt':300000}))
    assert result['funnel']['busy'] == 1 and result['status'] == 'no_eligible_candidates'


def test_explanation_uses_actual_description(profiles, query):
    query = query.model_copy(update={'wishes':'импровизацией'})
    card = match(profiles, query)['recommendations'][0]
    assert 'Свадьба с импровизацией' in card['explanation']
    assert 'стартовой ценой' in card['explanation']
    assert card['synthetic'] is True
